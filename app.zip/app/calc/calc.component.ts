import { Component } from '@angular/core';

@Component({
  selector: 'ng-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent  {
[x: string]: any;

public input:string='';
public result:string='';


prr(num:string){
  if(this.input=='1'){
    this.input=this.input+num;
  }
  return this.input;
}
pressnum(num: string){

  if(num=="."){
    //It means it can give you permission to enter decimal  again........
    if(this.input!=""){
  const lastNum=this.getLastNumber()
  console.log(lastNum.lastIndexOf("."))
  if(lastNum.lastIndexOf(".")>=0)
  return;
    }
  }
  if(num=="0"){
    if(this.input==""){
    return
    //doesn't allow zero at the beginning
  }
  const PrevKey=this.input[this.input.length-1];
  if(PrevKey==='/' || PrevKey==='*' || PrevKey==='-' || PrevKey==='+'){
    return
  }
}
this.input=this.input+num
this.answer();
}
getLastOperand() {
  let pos:number;
  console.log(this.input)
  pos=this.input.toString().lastIndexOf("+")
  if (this.input.toString().lastIndexOf("-") > pos) pos=this.input.lastIndexOf("-")
  if (this.input.toString().lastIndexOf("*") > pos) pos=this.input.lastIndexOf("*")
  if (this.input.toString().lastIndexOf("/") > pos) pos=this.input.lastIndexOf("/")
  console.log('Last '+this.input.substr(pos+1))
  return this.input.substr(pos+1)
}
pressoperator(op: string) {
 
  //Do not allow operators more than once
  const lastKey = this.input[this.input.length - 1];
  if (lastKey === '/' || lastKey === '*' || lastKey === '-' || lastKey === '+')  {
    return;
  }
 
  this.input = this.input + op
  this.calcAnswer();
}
Clear() {
  if (this.input !="" ) {
    this.input=this.input.substr(0, this.input.length-1)
  }
}
allClear() {
  this.result = '';
  this.input = '';
}

answer() {
  let formula = this.input;

  let lastKey = formula[formula.length - 1];

  if (lastKey === '.')  {
    formula=formula.substr(0,formula.length - 1);
  }

  lastKey = formula[formula.length - 1];

  if (lastKey === '/' || lastKey === '*' || lastKey === '-' || lastKey === '+' || lastKey === '.')  {
    formula=formula.substr(0,formula.length - 1);
  }
  console.log("Formula " +formula);
  this.result = eval(formula);
}

getAnswer() {
  this.calcAnswer();
  this.input = this.result;
  if (this.input=="0") this.input="";
}

}



